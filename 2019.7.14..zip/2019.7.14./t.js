window.onload = function() {
	returnTop();
	setInterval(function(){fnDate()},1000);   //加多一层函数才会动态变化？
	hotImgChange();
	landCheck();
	regCheck();
    startImg();
    starAssess();
}

//封装一个代替getElementById()的方法
function byId(id){
    return typeof(id) === "string"?document.getElementById(id):id;
}


// 返回顶部
function returnTop() {
	var timer = null;
	var top = byId("top");
	top.onclick = function fn(){
	    var oTop = document.body.scrollTop || document.documentElement.scrollTop;  
	    // 获得滚动高度
	    if(oTop > 0){
	        document.body.scrollTop = document.documentElement.scrollTop = oTop - Math.ceil(oTop/20);
	        timer = setTimeout(fn,10);
	    }else{
	        clearTimeout(timer);
	    }    
	}
}

// 日期
function fnDate() {
	var data = new Date();
	var time = data.toLocaleTimeString();
	byId("rvt-t").innerHTML = time;
}
// 航班切换
b1.onclick = function() {
	var con1 = byId("flights-1");
	var con2 = byId("flights-2");
	var but1 = byId("b1");
	var but2 = byId("b2");
	con1.style.display = "flex";
	con2.style.display = "none";
	but2.style.color = "#005CAF";
	but1.style.color = "#69C";
}
b2.onclick = function() {
	var con1 = byId("flights-1");
	var con2 = byId("flights-2");
	var but1 = byId("b1");
	var but2 = byId("b2");
	con2.style.display = "flex";
	con1.style.display = "none";
	but1.style.color = "#005CAF";
	but2.style.color = "#69C";
}
// 内容图片
function hotImgChange(){
	var hotImg = document.getElementsByClassName("hot-img");
	for(var i = 0;i < hotImg.length; i++) {
		hotImg[i].style.backgroundImage = "url(img/" + (1+i) + ".jpg)";
		hotImg[i].style.backgroundSize = "cover";
	}
}
// 正则
var lcheck1 = false;
var lcheck2 = false;
lemail.onchange = function(){
    var text = byId("warn1");
    var email = this.value;
    var e = byId("lemail");
    var reg = /^([a-zA-Z]|[0-9])(\w|\-)+@[a-zA-Z0-9]+\.([a-zA-Z]{2,4})$/;
    if(email === ""){
        text.innerHTML = "内容不可为空";
        text.style.color = "#d91f12";
        e.style.borderBottom = "2px solid #d91f12";
        lcheck1 = false;
    }else if(reg.test(email)){
        text.innerHTML = "成功";
        text.style.color = "#85ace0";
        e.style.borderBottom = "2px solid #85ace0";
        lcheck1 = true;
    }else{
        text.innerHTML = "请输入正确邮箱地址";
        text.style.color = "#d91f12";
        e.style.borderBottom = "2px solid #d91f12";
        lcheck1 = false;
    }
}
lpassword.onchange = function(){
    var text = byId("warn2");
    var password = this.value;
    var p = byId("lpassword");
    if(password === ""){
        text.innerHTML = "内容不可为空";
        text.style.color = "#d91f12";
        p.style.borderBottom = "2px solid #d91f12";
        lcheck2 = false;
    }else{
        text.innerHTML = "成功";
        text.style.color = "#85ace0";
        p.style.borderBottom = "2px solid #85ace0";
        lcheck2 = true;
    }
}
function landCheck(){
	var landBut = byId("land-but");
	if(lcheck1&&lcheck2){
		delete landBut.disabled;
	}
}

var rcheck1 = false;
var rcheck2 = false;
var rcheck3 = false;
remail.onchange = function(){
    var text = byId("warn3");
    var email = this.value;
    var e = byId("remail");
    var reg = /^([a-zA-Z]|[0-9])(\w|\-)+@[a-zA-Z0-9]+\.([a-zA-Z]{2,4})$/;
    if(email === ""){
        text.innerHTML = "内容不可为空";
        text.style.color = "#d91f12";
        e.style.borderBottom = "2px solid #d91f12";
        rcheck1 = false;
    }else if(reg.test(email)){
        text.innerHTML = "成功";
        text.style.color = "#85ace0";
        e.style.borderBottom = "2px solid #85ace0";
        rcheck1 = true;
    }else{
        text.innerHTML = "请输入正确邮箱地址";
        text.style.color = "#d91f12";
        e.style.borderBottom = "2px solid #d91f12";
        rcheck1 = false;
    }
}
rpassword1.onchange = function(){
    var text = byId("warn4");
    var password = this.value;
    var p = byId("rpassword1");
    if(password === ""){
        text.innerHTML = "内容不可为空";
        text.style.color = "#d91f12";
        p.style.borderBottom = "2px solid #d91f12";
        rcheck2 = false;
    }else{
        text.innerHTML = "成功";
        text.style.color = "#85ace0";
        p.style.borderBottom = "2px solid #85ace0";
        rcheck2 = true;
    }
}
rpassword2.onchange = function(){
    var text = byId("warn5");
    var password = this.value;
    var p = byId("rpassword2");
    if(password === ""){
        text.innerHTML = "内容不可为空";
        text.style.color = "#d91f12";
        p.style.borderBottom = "2px solid #d91f12";
        rcheck3 = false;
    }else if(password != byId("rpassword1").value){
        text.innerHTML = "请输入相同的密码";
        text.style.color = "#d91f12";
        p.style.borderBottom = "2px solid #d91f12";
        rcheck3 = false;
    }else{
        text.innerHTML = "成功";
        text.style.color = "#85ace0";
        p.style.borderBottom = "2px solid #85ace0";
        rcheck3 = true;
    }
}
function regCheck(){
	var regBut = byId("reg-but");
	if(rcheck1&&rcheck2&&rcheck3){
		delete regBut.disabled;
	}
}
// 登录注册弹出框
var lOpen = byId("land-open");
var lClose = byId("land-close");
var rOpen = byId("reg-open");
var rClose = byId("reg-close");
var r_lOpen = byId("lreg-but");
var l_rOpen = byId("rland-but");
var landBox = byId("land-box");
var regBox = byId("reg-box");
var mask = byId("mask");
lOpen.onclick = function(){
	mask.style.display = "block";
	landBox.style.display = "block";
}
lClose.onclick = function(){
	mask.style.display = "none";
	landBox.style.display = "none";
}
rOpen.onclick = function(){
	mask.style.display = "block";
	regBox.style.display = "block";
}
rClose.onclick = function(){
	mask.style.display = "none";
	regBox.style.display = "none";
}
r_lOpen.onclick = function(){
	landBox.style.display = "none";
	regBox.style.display = "block";
	return false;
}
l_rOpen.onclick = function(){     
	regBox.style.display = "none";
	landBox.style.display = "block";
	return false;
}


// 轮播图
var adv = byId("adv");
var imgUl = byId("adv-img-ul");
var right = byId("right");
var left = byId("left");
var button = byId("adv-img-num").children;
var index = 1;

//改变位置
function animate(offset){
    var newLeft = parseInt(imgUl.style.left) + offset;
    if(newLeft < -400){
        // 到了最右
        imgUl.style.left = 0 + '%';
    }else if(newLeft > 0){
        // 到了最左
        imgUl.style.left = -400 + '%';
    }else{
        imgUl.style.left = newLeft + '%';  
    }
}


//自动轮播 鼠标悬停暂停
var timer = null;
function startImg(){
    if(timer)clearInterval(timer);
    timer = setInterval(function(){
        right.onclick();
    },2000);
}
adv.onmouseover = function stopImg(){
    clearInterval(timer);
}
adv.onmouseout = function startImg(){
    if(timer)clearInterval(timer);
    timer = setInterval(function(){
        right.onclick();
    },2000);
}
// 我一定要写两个原装开始才会动？？什么毛病？？

//下面按钮
function buttonShow(){
    // 清除原有样式
    for(var i=0; i<button.length; i++){
        if (button[i].className == 'on') {
            button[i].className = '';
        }
    }
    button[index-1].className = 'on';

}
left.onclick = function(){
    index -= 1;
    if(index < 1){
        index = 5;
    }
    buttonShow();
    animate(100);
}
right.onclick = function(){
    index += 1;
    if(index > 5){
        index = 1;
    }
    buttonShow();
    animate(-100);
}
//点击按钮跳转
for (var i = 0; i < button.length; i++) {
    // 立即执行函数 不闭包就只执行i=5时候
    (function(i) {
        button[i].onclick = function() {
            var clickIndex = parseInt(this.getAttribute('index'));
            var offset = 100 * (index - clickIndex); 
            animate(offset);
            index = clickIndex;
            buttonShow();
        }
    })(i)
}



// flash轮播图
var smallImg = byId("small-img").children;  // 从1开始才是图片
var emptyBox = byId("empty-box");
var bigImg = byId("big-img");
var bigPic = byId("big-pic");
for(var i = 1; i < smallImg.length; i++){
	(function(i){
		smallImg[i].onmouseover = function(){
		var onmouse = parseInt(this.getAttribute('alt'));
		emptyBox.style.left = (onmouse-1) * 105 + 6;
		bigImg.src = "img/" + i + ".jpg";
        bigPic.src = "img/" + i + ".jpg";
	}
	})(i);
}

// 放大镜
// bug：根据窗口定位卧槽？？？所以每次位置不同就有不同的bug？？？我tm找了一天就在想为什么每次刷新都是新的体验？？？
var smallBox = byId("small-box");
var bigBox = byId("big-glass");
var tool = byId("tool");

// 放大镜遮罩层
smallBox.onmouseenter = function(){
	tool.className = "tool active";
	bigBox.className = "big-glass active";
}
smallBox.onmouseleave = function(){
    tool.className = "tool";
    bigBox.className = "big-glass";
}
// 区域随着鼠标移动
smallBox.onmousemove = function(e){
    // 事件对象
    var _e = window.event||e;
    var x = _e.clientX - this.offsetLeft - tool.offsetWidth/2 -145;
    var y = _e.clientY - this.offsetTop - tool.offsetHeight/2 -150;
    // 左移出
    if(x < 0){
        x = 0;
    }
    // 上移出
    if(y < 0){
        y = 0;
    }
    // 右移出
    if(x>this.offsetWidth-tool.offsetWidth){
        x = this.offsetWidth-tool.offsetWidth;
    }
    // 下移出
    if(y>this.offsetHeight-tool.offsetHeight){
        y = this.offsetHeight-tool.offsetHeight;
    }
    tool.style.left = x + "px";
    tool.style.top = y + "px" ;
    bigPic.style.left = -x*2 + "px";
    bigPic.style.top = -y*2 + "px";
}

// 星级评比
var assessStrip = byId("assess-strip").children;
var texts = ["很差","不好","一般","不错","很好"];
var textAssess = byId("text-assess");

function starClear(){
    for (var i = 0;i < assessStrip.length;i++){
        assessStrip[i].className = "emptystar";
    }
}
function starAssess(){
    var leftstar = document.getElementsByClassName("leftstar");
    var rightstar = document.getElementsByClassName("rightstar");
    var temp = 0;
    for(var i = 0; i < assessStrip.length;i++){
        (function(i){
            rightstar[i].onmouseover = function(){
                var starnum = i;
                starClear();
                if(i < 3){
                    for(var j = 0;j < starnum + 1;j++){
                    assessStrip[j].className = "emptystar blackfullstar";
                }
                }else{
                    for(var j = 0;j < starnum + 1;j++){
                        assessStrip[j].className = "emptystar fullstar";
                    }
                }
            }
        })(i);
    }
    for(var i = 0; i < assessStrip.length;i++){
        (function(i){
            leftstar[i].onmouseover = function(){
                var starnum = i;
                starClear();
                if(i < 3){
                    for(var j = 0;j < starnum ;j++){
                    assessStrip[j].className = "emptystar blackfullstar";
                    }
                    assessStrip[starnum].className = "emptystar blackhalfstar";
                }else{
                    for(var j = 0;j < starnum ;j++){
                        assessStrip[j].className = "emptystar fullstar";
                    }
                    assessStrip[starnum].className = "emptystar halfstar";
                }
            }
        })(i);
    }
    for(var i = 0; i < assessStrip.length;i++){
        (function(i){
            rightstar[i].onclick = function(){
                textShow(i*2+2);
            }
        })(i);
    }
    for(var i = 0; i < assessStrip.length;i++){
        (function(i){
            leftstar[i].onclick = function(){
                textShow(i*2+1);
            }
        })(i);
    }
    function textShow(temp){
        var _temp = temp%2 == 0 ? temp/2-1 : (temp-1)/2;
        textAssess.innerHTML = texts[_temp] + "-" + temp + "分";
    }
}

// 进入商品详情
var produce = document.getElementsByClassName('thing');
var detail = byId('producedetail');
var detailReturn = byId('detail-return');
for(var i = 0; i < produce.length;i++){
    (function(i){
        produce[i].onclick = function(){
            mask.style.display = "block";
            detail.style.display = "block";
        }
    })(i);
}
detailReturn.onclick = function(){
    mask.style.display = "none";
    detail.style.display = "none";
}