window.onload = function() {
	returnTop();
	setInterval(function(){fnDate()},1000);   //加多一层函数才会动态变化？
	hotImgChange();
	landCheck();
	regCheck();
    startImg();
    starAssess();
    checkCookie();
    firstPage();
}

//封装一个代替getElementById()的方法
function byId(id){
    return typeof(id) === "string"?document.getElementById(id):id;
}


// 返回顶部
function returnTop() {
	var timer = null;
	var top = byId("top");
	top.onclick = function fn(){
	    var oTop = document.body.scrollTop || document.documentElement.scrollTop;  
	    // 获得滚动高度
	    if(oTop > 0){
	        document.body.scrollTop = document.documentElement.scrollTop = oTop - Math.ceil(oTop/20);
	        timer = setTimeout(fn,10);
	    }else{
	        clearTimeout(timer);
	    }    
	}
}

// 日期
function fnDate() {
	var data = new Date();
	var time = data.toLocaleTimeString();
	byId("rvt-t").innerHTML = time;
}
// 航班切换
b1.onclick = function() {
	var con1 = byId("flights-1");
	var con2 = byId("flights-2");
	var but1 = byId("b1");
	var but2 = byId("b2");
	con1.style.display = "flex";
	con2.style.display = "none";
	but2.style.color = "#005CAF";
	but1.style.color = "#69C";
}
b2.onclick = function() {
	var con1 = byId("flights-1");
	var con2 = byId("flights-2");
	var but1 = byId("b1");
	var but2 = byId("b2");
	con2.style.display = "flex";
	con1.style.display = "none";
	but1.style.color = "#005CAF";
	but2.style.color = "#69C";
}
// 内容图片
function hotImgChange(){
	var hotImg = document.getElementsByClassName("hot-img");
	for(var i = 0;i < hotImg.length; i++) {
		hotImg[i].style.backgroundImage = "url(img/" + (1+i) + ".jpg)";
		hotImg[i].style.backgroundSize = "cover";
	}
}
// 正则
var lOpen = byId("land-open");
var lClose = byId("land-close");
var rOpen = byId("reg-open");
var rClose = byId("reg-close");
var r_lOpen = byId("lreg-but");
var l_rOpen = byId("rland-but");
var landBox = byId("land-box");
var regBox = byId("reg-box");
var mask = byId("mask");
var successText = byId("success");
var out = byId("out");
var remenber = byId("remenber");

var lcheck1 = false;
var lcheck2 = false;
lemail.onchange = function(){
    var text = byId("warn1");
    var email = this.value;
    var e = byId("lemail");
    // var reg = /^([a-zA-Z]|[0-9])(\w|\-)+@[a-zA-Z0-9]+\.([a-zA-Z]{2,4})$/;
    if(email === ""){
        text.innerHTML = "内容不可为空";
        text.style.color = "#d91f12";
        e.style.borderBottom = "2px solid #d91f12";
        lcheck1 = false;
    }else{          //  if(reg.test(email))
        text.innerHTML = "成功";
        text.style.color = "#85ace0";
        e.style.borderBottom = "2px solid #85ace0";
        lcheck1 = true;
        landCheck();
    }
    // }else{
    //     text.innerHTML = "请输入正确邮箱地址";
    //     text.style.color = "#d91f12";
    //     e.style.borderBottom = "2px solid #d91f12";
    //     lcheck1 = false;
    // }
}
lpassword.onchange = function(){
    var text = byId("warn2");
    var password = this.value;
    var p = byId("lpassword");
    if(password === ""){
        text.innerHTML = "内容不可为空";
        text.style.color = "#d91f12";
        p.style.borderBottom = "2px solid #d91f12";
        lcheck2 = false;
    }else{
        text.innerHTML = "成功";
        text.style.color = "#85ace0";
        p.style.borderBottom = "2px solid #85ace0";
        lcheck2 = true;
        landCheck();
    }
}
function landCheck(){
	var landBut = byId("land-but");
	if(lcheck1&&lcheck2){
        landBut.disabled = false;
        landBut.className = "box-but-can"
	}
}

//曹越测试
function test11(){
    let account = 'user1';
    let password = '123456';
    $.ajax({
        url:'http://123.207.52.59:8088/login',  
        data:{
            "account":account,
            "password":password
        },      
        type:'post',        
        dataType:'JSON',        
        success:function(){
            console.log('成功'); 
        },
        error:function(){  
            console.log('尼玛');
        }
      });
}
// 设置
function setCookie(cname,cvalue,exdays){
	var day = new Date();
	day.setTime(day.getTime()+(exdays*24*60*60*1000));
	var expires = "expires="+day.toGMTString();
	document.cookie = cname+"="+cvalue+"; "+expires;
}
// 获取
function getCookie(cname){
	var name = cname + "=";
	var ca = document.cookie.split(';');
	for(var i=0; i<ca.length; i++) {
		var c = ca[i].trim();
		if (c.indexOf(name)==0) { return c.substring(name.length,c.length); }
	}
	return "";
}
// 进入网页时检验
function checkCookie(){
	var user=getCookie("username");
	if (user!=""){
		mask.style.display = "none";
        landBox.style.display = "none";
        lOpen.style.display = "none";
        rOpen.style.display = "none";
        success.innerHTML = user + "Name登录成功";
        out.style.display = "inline-block";
	}
}
// 登录时创造
function creatCookie(){
    user = $.trim($("#lemail").val());
    if (user!="" && user!=null){
        setCookie("username",user,7);
    }
}
// 清除
function clearCookie(name) {
    setCookie(name, "", -1);
}




$(function(){
    $("#land-but").click(function(){
        var user = new Object();
        user.loginCode = $.trim($("#lemail").val());
        user.password = $.trim($("#lpassword").val());
        $.ajax({
            url:'http://123.207.52.59:8088/login',  
            data:{
                "account":user.loginCode,
                "password":user.password
            },      
            type:'post',        
            dataType:'JSON',        
            success:function(data){
                console.log(data);
                if(data.status==1){
                    mask.style.display = "none";
                    landBox.style.display = "none";
                    lOpen.style.display = "none";
                    rOpen.style.display = "none";
                    success.innerHTML = data.data.userName + data.msg;
                    out.style.display = "inline-block";
                    if($("#remenber").is(':checked')){
                        creatCookie();
                    }
                }else if(data.status==0){
                    alert(data.msg);
                }
            },
            error:function(){  
                alert("fail!");
            }
          });           
    });
});

out.onclick = function(){
    clearCookie("username");
    lOpen.style.display = "inline-block";
    rOpen.style.display = "inline-block";
    out.style.display = "none";
    success.innerHTML = "";
}






var rcheck1 = false;
var rcheck2 = false;
var rcheck3 = false;
remail.onchange = function(){
    var text = byId("warn3");
    var email = this.value;
    var e = byId("remail");
    var reg = /^([a-zA-Z]|[0-9])(\w|\-)+@[a-zA-Z0-9]+\.([a-zA-Z]{2,4})$/;
    if(email === ""){
        text.innerHTML = "内容不可为空";
        text.style.color = "#d91f12";
        e.style.borderBottom = "2px solid #d91f12";
        rcheck1 = false;
    }else if(reg.test(email)){
        text.innerHTML = "成功";
        text.style.color = "#85ace0";
        e.style.borderBottom = "2px solid #85ace0";
        rcheck1 = true;
        regCheck();
    }else{
        text.innerHTML = "请输入正确邮箱地址";
        text.style.color = "#d91f12";
        e.style.borderBottom = "2px solid #d91f12";
        rcheck1 = false;
    }
}
rpassword1.onchange = function(){
    var text = byId("warn4");
    var password = this.value;
    var p = byId("rpassword1");
    if(password === ""){
        text.innerHTML = "内容不可为空";
        text.style.color = "#d91f12";
        p.style.borderBottom = "2px solid #d91f12";
        rcheck2 = false;
    }else{
        text.innerHTML = "成功";
        text.style.color = "#85ace0";
        p.style.borderBottom = "2px solid #85ace0";
        rcheck2 = true;
        regCheck();
    }
}
rpassword2.onchange = function(){
    var text = byId("warn5");
    var password = this.value;
    var p = byId("rpassword2");
    if(password === ""){
        text.innerHTML = "内容不可为空";
        text.style.color = "#d91f12";
        p.style.borderBottom = "2px solid #d91f12";
        rcheck3 = false;
    }else if(password != byId("rpassword1").value){
        text.innerHTML = "请输入相同的密码";
        text.style.color = "#d91f12";
        p.style.borderBottom = "2px solid #d91f12";
        rcheck3 = false;
    }else{
        text.innerHTML = "成功";
        text.style.color = "#85ace0";
        p.style.borderBottom = "2px solid #85ace0";
        rcheck3 = true;
        regCheck();
    }
}
function regCheck(){
	var regBut = byId("reg-but");
	if(rcheck1&&rcheck2&&rcheck3){
		regBut.disabled = false;
        regBut.className = "box-but-can"
	}
}


// 登录注册弹出框
lOpen.onclick = function(){
	mask.style.display = "block";
	landBox.style.display = "block";
}
lClose.onclick = function(){
	mask.style.display = "none";
	landBox.style.display = "none";
}
rOpen.onclick = function(){
	mask.style.display = "block";
	regBox.style.display = "block";
}
rClose.onclick = function(){
	mask.style.display = "none";
	regBox.style.display = "none";
}
r_lOpen.onclick = function(){
	landBox.style.display = "none";
	regBox.style.display = "block";
	return false;
}
l_rOpen.onclick = function(){     
	regBox.style.display = "none";
	landBox.style.display = "block";
	return false;
}


// 轮播图
var adv = byId("adv");
// var imgUl = byId("adv-img-ul");
var advImg = byId("adv-img-ul").children;
var right = byId("right");
var left = byId("left");
var button = byId("adv-img-num").children;
var index = 1;

//改变位置
// function animate(offset){
//     var newLeft = parseInt(imgUl.style.left) + offset;
//     if(newLeft < -400){
//         // 到了最右
//         imgUl.style.left = 0 + '%';
//     }else if(newLeft > 0){
//         // 到了最左
//         imgUl.style.left = -400 + '%';
//     }else{
//         imgUl.style.left = newLeft + '%';  
//     }
// }
function animate(num){
    for(var i = 0;i < advImg.length;i++){
        advImg[i].style.opacity = 0;
    }
    advImg[num].style.opacity = 1;
}



//自动轮播 鼠标悬停暂停
var timer = null;
function startImg(){
    if(timer)clearInterval(timer);
    timer = setInterval(function(){
        right.onclick();
    },3000);
}
adv.onmouseover = function stopImg(){
    clearInterval(timer);
}
adv.onmouseout = function startImg(){
    if(timer)clearInterval(timer);
    timer = setInterval(function(){
        right.onclick();
    },3000);
}
// 我一定要写两个原装开始才会动？？什么毛病？？

//下面按钮
function buttonShow(){
    // 清除原有样式
    for(var i=0; i<button.length; i++){
        if (button[i].className == 'on') {
            button[i].className = '';
        }
    }
    button[index-1].className = 'on';

}
// left.onclick = function(){
//     index -= 1;
//     if(index < 1){
//         index = 5;
//     }
//     buttonShow();
//     animate(100);
// }
left.onclick = function(){
    index -= 1;
    if(index < 1)index = 5;
    animate(index-1);
    buttonShow();
}
// right.onclick = function(){
//     index += 1;
//     if(index > 5){
//         index = 1;
//     }
//     buttonShow();
//     animate(-100);
// }
right.onclick = function(){
    index += 1;
    if(index > 5)index = 1;
    animate(index-1);
    buttonShow();
}
//点击按钮跳转
// for (var i = 0; i < button.length; i++) {
//     // 立即执行函数 不闭包就只执行i=5时候
//     (function(i) {
//         button[i].onclick = function() {
//             var clickIndex = parseInt(this.getAttribute('index'));
//             var offset = 100 * (index - clickIndex); 
//             animate(offset);
//             index = clickIndex;
//             buttonShow();
//         }
//     })(i)
// }
for (var i = 0; i < button.length; i++) {
    // 立即执行函数 不闭包就只执行i=5时候
    (function(i) {
        button[i].onclick = function() {
            var clickIndex = parseInt(this.getAttribute('index'));
            animate(clickIndex-1);
            index = clickIndex;
            buttonShow();
        }
    })(i)
}

// 放大镜
// bug：根据窗口定位卧槽？？？所以每次位置不同就有不同的bug？？？我tm找了一天就在想为什么每次刷新都是新的体验？？？
var smallBox = byId("small-box");
var bigBox = byId("big-glass");
var tool = byId("tool");

// 放大镜遮罩层
smallBox.onmouseenter = function(){
	tool.className = "tool active";
	bigBox.className = "big-glass active";
}
smallBox.onmouseleave = function(){
    tool.className = "tool";
    bigBox.className = "big-glass";
}
// 区域随着鼠标移动
smallBox.onmousemove = function(e){
    // 事件对象
    var _e = window.event||e;
    var x = _e.clientX - this.offsetLeft - tool.offsetWidth/2 -145;
    var y = _e.clientY - this.offsetTop - tool.offsetHeight/2 -180;
    // 左移出
    if(x < 0){
        x = 0;
    }
    // 上移出
    if(y < 0){
        y = 0;
    }
    // 右移出
    if(x>this.offsetWidth-tool.offsetWidth){
        x = this.offsetWidth-tool.offsetWidth;
    }
    // 下移出
    if(y>this.offsetHeight-tool.offsetHeight){
        y = this.offsetHeight-tool.offsetHeight;
    }
    tool.style.left = x + "px";
    tool.style.top = y + "px" ;
    bigPic.style.left = -x*2 + "px";
    bigPic.style.top = -y*2 + "px";
}

// 星级评比
var assessStrip = byId("assess-strip").children;
var texts = ["很差","不好","一般","不错","很好"];
var textAssess = byId("text-assess");
var leftstar = document.getElementsByClassName("leftstar");
var rightstar = document.getElementsByClassName("rightstar");
var temp = 0;
function starClear(){
    for (var i = 0;i < assessStrip.length;i++){
        assessStrip[i].className = "emptystar";
    }
}
function starAssess(){
    for(var i = 0; i < assessStrip.length;i++){
        (function(i){
            rightstar[i].onmouseover = function(){
                var starnum = i;
                starClear();
                if(i < 3){
                    for(var j = 0;j < starnum + 1;j++){
                    assessStrip[j].className = "emptystar blackfullstar";
                }
                }else{
                    for(var j = 0;j < starnum + 1;j++){
                        assessStrip[j].className = "emptystar fullstar";
                    }
                }
            }
        })(i);
    }
    for(var i = 0; i < assessStrip.length;i++){
        (function(i){
            leftstar[i].onmouseover = function(){
                var starnum = i;
                starClear();
                if(i < 3){
                    for(var j = 0;j < starnum ;j++){
                    assessStrip[j].className = "emptystar blackfullstar";
                    }
                    assessStrip[starnum].className = "emptystar blackhalfstar";
                }else{
                    for(var j = 0;j < starnum ;j++){
                        assessStrip[j].className = "emptystar fullstar";
                    }
                    assessStrip[starnum].className = "emptystar halfstar";
                }
            }
        })(i);
    }
    for(var i = 0; i < assessStrip.length;i++){
        (function(i){
            rightstar[i].onclick = function(){
                textShow(i*2+2);
            }
        })(i);
    }
    for(var i = 0; i < assessStrip.length;i++){
        (function(i){
            leftstar[i].onclick = function(){
                textShow(i*2+1);
            }
        })(i);
    }
    function textShow(temp){
        var _temp = temp%2 == 0 ? temp/2-1 : (temp-1)/2;
        textAssess.innerHTML = texts[_temp] + "-" + temp + "分";
    }
}




// 分页
var things = byId("things");
var pageNum = byId("pagenum");
var limit = 4;
var pageCount = 1;
// 第一页
function firstPage(){
    $.ajax({
        url:'http://123.207.52.59:8088/paging',  
        data:{
            "limit":limit,
            "page":1
        },      
        type:'get',        
        dataType:'JSON',        
        success:function(data){
            if(data.status==1){
                var count = data.data.count;
                // 第一页
                var firPageNum = document.createElement("button");
                var fir = document.createTextNode(1);
                firPageNum.appendChild(fir);
                pageNum.appendChild(firPageNum);
                firPageNum.setAttribute("id",1);
                firPageNum.className = "pagenum-but-h";
                firPageNum.addEventListener("click",function(){pagePro(this.id);});
                // 不满一页
                if(data.data.count<limit){
                    for(var i=1;i<=data.data.count;i++){
                        oPro(i);
                    }
                    for(var i=0;i<limit-count;i++){
                        var emptyThing = document.createElement("div");
                        emptyThing.className = "emptything";
                        things.appendChild(emptyThing);
                    }
                // 大于一页
                }else{
                    for(var i=2;count>limit;i++){
                        // 生成后面的页码
                        var newPageNum = document.createElement("button");
                        var num = document.createTextNode(i);
                        newPageNum.appendChild(num);
                        pageNum.appendChild(newPageNum);
                        newPageNum.setAttribute("id",i);
                        newPageNum.className = "pagenum-but";
                        count -= limit;
                        pageCount++;
                        newPageNum.addEventListener("click",function(){pagePro(this.id);});
                    }
                    pagePro(1);
                }
            }else if(data.status==0){
                alert(data.msg);
            }
        },
        error:function(){  
            alert("fail!");
        }
      });
}
// 跳转页面 加载每一页产品
var oFirstPage = byId("firstpage");
var oLastPage = byId("lastpage");
var prePage = byId("prepage");
var nextPage = byId("nextpage");
function pagePro(pageNum){
    $.ajax({
        url:'http://123.207.52.59:8088/paging',  
        data:{
            "limit":limit,
            "page":pageNum
        },      
        type:'get',        
        dataType:'JSON',        
        success:function(data){
            console.log(data);
             if(data.status==0){
                 alert(msg);
             }else{
                //  清掉原来的产品
                if(things.children.length!=0){
                    var thing = things.children;
                    for(var i=0;i<limit;i++){
                        things.removeChild(thing[0]);
                        if(thing[0]==null)break;
                    }
                }
                // 页码样式
                var oPage = byId("pagenum").children;
                if(oPage.length>=1){
                    for(var i=0;i<pageCount;i++){
                        oPage[i].className = "pagenum-but";
                    }
                    oPage[pageNum-1].className = "pagenum-but-h";
                }
                // 首页 尾页 上一页 下一页
                if(pageNum==1){
                    oFirstPage.className = "unclick";
                    oFirstPage.disabled = true;
                    oLastPage.className = "canclick";
                    oLastPage.disabled = false;
                    prePage.className = "unclick";
                    prePage.disabled = true;
                    nextPage.className = "canclick";
                    nextPage.disabled = false;
                }else if(pageNum==pageCount){
                    oFirstPage.className = "canclick";
                    oFirstPage.disabled = false;
                    oLastPage.className = "unclick";
                    oLastPage.disabled = true;
                    prePage.className = "canclick";
                    prePage.disabled = false;
                    nextPage.className = "unclick";
                    nextPage.disabled = true;
                }else{
                    oFirstPage.className = "canclick";
                    oFirstPage.disabled = false;
                    oLastPage.className = "canclick";
                    oLastPage.disabled = false;
                    prePage.className = "canclick";
                    prePage.disabled = false;
                    nextPage.className = "canclick";
                    nextPage.disabled = false;
                }
                //  满一页
                 if(data.data.count>=pageNum*limit){
                    for(var i=0;i<limit;i++){
                        oPro(data.data.idList[i]);
                    }
                // 不满一页
                }else{
                    for(var i=0;i<data.data.count-(pageNum-1)*limit;i++){
                        oPro(data.data.idList[i]);
                    }
                }
             }
        },
        error:function(){  
            alert("fail!")
        }
      });
}
// 跳转首页 尾页 上一页 下一页
oFirstPage.onclick = function(){
    pagePro(1);
}
oLastPage.onclick = function(){
    pagePro(pageCount);
}
prePage.onclick = function(){
    var nowPage = document.getElementsByClassName("pagenum-but-h");
    pagePro(parseInt(nowPage[0].getAttribute("id"))-1);
}
nextPage.onclick = function(){
    var nowPage = document.getElementsByClassName("pagenum-but-h");
    pagePro(parseInt(nowPage[0].getAttribute("id"))+1);
}


// 获取单个产品
function oPro(id){
    $.ajax({
        url:'http://123.207.52.59:8088/getInfo',  
        data:{
            "id":id
        },      
        type:'get',        
        dataType:'JSON',        
        success:function(data){
            if(data.status==1){
                var pro = document.createElement("div");
                pro.className = "thing";
                things.appendChild(pro);
                var proImg = document.createElement("img");
                proImg.src = data.data.img;
                pro.appendChild(proImg);
                var name = document.createElement("p");
                var proName = document.createTextNode("名称：" + data.data.name);
                name.appendChild(proName);
                pro.appendChild(name);
                var hot = document.createElement("p");
                var proHot = document.createTextNode("人气：" + data.data.hot);
                hot.appendChild(proHot);
                pro.appendChild(hot);
                var price = document.createElement("p");
                var proPrice = document.createTextNode("价格：" + data.data.price);
                price.appendChild(proPrice);
                pro.appendChild(price);
                var intro = document.createElement("p");
                var proIntro = document.createTextNode("描述：" + data.data.introduction);
                intro.appendChild(proIntro);
                pro.appendChild(intro);
                pro.addEventListener("click",function(){showDetail(id);});
            }else if(data.status==0){
                alert(data.msg);
            }
        },
        error:function(){  
            alert("fail!");
        }
      });
}



// 进入商品详情
var produce = document.getElementsByClassName('thing');
var emptyBox = byId("empty-box");
var bigImg = byId("big-img");
var bigPic = byId("big-pic");
var detail = byId('producedetail');
var detailReturn = byId('detail-return');
function showDetail(id){
    mask.style.display = "block";
    detail.style.display = "block";
    $.ajax({
        url:'http://123.207.52.59:8088/getImg',  
        data:{
            "id":id
        },      
        type:'get',        
        dataType:'JSON',        
        success:function(data){
            console.log(id); 
            // flash轮播图
            var imgCount = data.data.detailedImg.length;
            var smallImg = byId("small-img");
            // 清除原来的图
            if(smallImg.children.length>1){
                for(var i=1;;i++){
                    // 第一个是空外框
                    smallImg.removeChild(smallImg.children[1]);
                    if(smallImg.children[1]==null)break;
                }
            }
            // 加入新图
            for(var i=0;i<imgCount;i++){
                var detailImg = document.createElement("img");
                detailImg.src = data.data.detailedImg[i];
                detailImg.setAttribute("alt",i+1);
                smallImg.appendChild(detailImg);
            }
            emptyBox.style.left = 0;
            var smallPic = smallImg.children;  // 从1开始才是图片
            bigImg.src = data.data.detailedImg[0];
            bigPic.src = data.data.detailedImg[0];
            for(var i=1;i<=imgCount;i++){
                smallPic[i].addEventListener("mouseover",function(){
                    var onmouse = parseInt(this.getAttribute('alt'));
                    emptyBox.style.left = (onmouse-1) * 100;
                    bigImg.src = data.data.detailedImg[onmouse-1];
                    bigPic.src = data.data.detailedImg[onmouse-1];
                });
            }
        },
        error:function(){  
            alert("fail!");
        }
      });
}

detailReturn.onclick = function(){
    mask.style.display = "none";
    detail.style.display = "none";
    starClear();
    textAssess.innerHTML = "评价";
}
